/************************************************************************
*
* MODULE: nwm_Stubs.c
*
* OWNER:
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION:
*
*************************************************************************/
#include "global.h"

UINT16 nwm_HTTP_Send_Data(void){
    return 0;
}
void nwm_HTTP_SW_Update(void){

}
