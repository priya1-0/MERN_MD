/************************************************************************
*
* MODULE: 2490G_Defaults.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This is a development-only function to set the NV storage
* to safe testing values.
*
*************************************************************************/


void setNVDefaultsForDevelopment(void);
