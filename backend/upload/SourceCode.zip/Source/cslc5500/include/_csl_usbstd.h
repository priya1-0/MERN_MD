/******************************************************************************\
*           Copyright (C) 2001 Texas Instruments Incorporated.                *
*                           All Rights Reserved                               *
*                                                                             *
*                                                                             *
*                                                                             *
*******************************************************************************
* Name:  usb_stdinc.h                                                         *
*                                                                             *
\******************************************************************************/


#ifndef _USB_STDINC_H_
#define _USB_STDINC_H_


/*typedef unsigned char	Uchar;*/
/*typedef unsigned short	Uint16;*/
/*typedef unsigned long 	Uint32;*/
/*typedef short		    Int16;*/
/*typedef long		    Int32;*/
/*typedef void *          Handle;*/

#endif
