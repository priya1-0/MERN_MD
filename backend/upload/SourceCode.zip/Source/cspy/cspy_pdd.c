

// Uncomment only one. Ones marked "TOO LARGE have data blocks 
// too large for the TI Code Composer compiler.

// SCR 82664 - 7230 files

//#include "c:\dev\2490G\cspy\SCR82664\7230std\cspy_pdd_emptybuf.c"
//#include "c:\dev\2490G\cspy\SCR82664\7230std\cspy_pdd_invbuf.c"
//#include "c:\dev\2490G\cspy\SCR82664\7230std\cspy_pdd_maxbuf.c"
//#include "c:\dev\2490G\cspy\SCR82664\7230std\cspy_pdd_midbuf.c"
//#include "c:\dev\2490G\cspy\SCR82664\7230std\cspy_pdd_minbuf.c"
//#include "c:\dev\2490G\cspy\SCR82664\7230std\cspy_pdd_wrapbuf.c"


// SCR 82664 - 7274 files

//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_clearall.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_empepdta.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_emprrall.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_emptylog.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_emtylog2.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_emtyltct.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_instltct.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invepdta.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invrrall.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invrrcur.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invrrvf.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invrrvt.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invst2.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_invstate.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_maxepdta.c"  << TOO LARGE
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_maxlog.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_maxlog2.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_maxltct.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_maxrrall.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_midepdta.c" << TOO LARGE
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_midlog.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_midlog2.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_midltct.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_midrrall.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_minepdta.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_minlog.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_minlog2.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_minltct.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_minrrall.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_parampor.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_validrr.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_wraepdta.c"  << TOO LARGE
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_wraplog.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_wraplog2.c"
//#include "c:\dev\2490G\cspy\SCR82664\7274std\cspy_pdd_wrarrall.c"




