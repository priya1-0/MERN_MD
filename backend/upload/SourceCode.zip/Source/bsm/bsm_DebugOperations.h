/************************************************************************
*
* MODULE: bsm_DebugOperations.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function declarations for the
*              serial port.
*
*************************************************************************/
#ifndef BSM_DEBUGOPERATIONS_H
#define BSM_DEBUGOPERATIONS_H

///////////////
// prototypes
///////////////

BOOL ExecuteCommand(char* CommandLine);

#endif
