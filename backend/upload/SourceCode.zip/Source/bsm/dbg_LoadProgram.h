/************************************************************************
*
* MODULE: dbg_LoadProgram.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to update the software
*
*************************************************************************/
#ifndef DBG_LOADPROGRAM_H
#define DBG_LOADPROGRAM_H

////////////
// Prototype
////////////
void LoadProgram(char* Parameters);

#endif
