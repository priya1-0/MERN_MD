/************************************************************************
*
* MODULE: bsm_HaltTesting.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function declarations for the
*              HALT Testing function.
*
*************************************************************************/
#ifndef BSM_HALTTESTING_H
#define BSM_HALTTESTING_H

///////////////
// prototypes
///////////////

void bsm_HaltTesting(void);

#endif
