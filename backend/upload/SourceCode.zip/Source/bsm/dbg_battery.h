/************************************************************************
*
* MODULE: dbg_battery.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to debug the battery
*
*************************************************************************/
#ifndef DBG_BATTERY_H
#define BDG_BATTERY_H

/////////////
// Prototypes
/////////////
void ReadBatteryThreshold(void);

#endif
