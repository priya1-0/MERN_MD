/************************************************************************
*
* MODULE: dbg_TestExternalRam.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the functions to test the external RAM.
*
*************************************************************************/
#ifndef DBG_TESTEXTERNALRAM_H
#define DBG_TESTEXTERNALRAM_H

/////////////
// Prototypes
/////////////
BOOL TestSdram(void);

#endif

