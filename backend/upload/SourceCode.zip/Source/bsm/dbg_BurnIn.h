/************************************************************************
*
* MODULE: dbg_BurnIn.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to run the burn in.
*
*************************************************************************/
#ifndef DBG_BURNIN_H
#define DBG_BURNIN_H

/////////////
// Prototypes
/////////////
void BurnInTest(void);

#endif
