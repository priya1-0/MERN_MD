/************************************************************************
*
* MODULE: bsm_TestMaxSessionTime.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function declarations for the
*              Max Session Simulation Time.
*
*************************************************************************/
#ifndef BSM_TESTMAXSESSIONTIME_H
#define BSM_TESTMAXSESSIONTIME_H

///////////////
// prototypes
///////////////
void bsm_TestMaxSessionTime(void);

#endif
