/************************************************************************
*
* MODULE: dbg_menu.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function declarations for the
*              debug menu.
*
*************************************************************************/

///////////////
// prototypes
///////////////
void PrintMenu(void);
void PrintEepromAddr(void);
