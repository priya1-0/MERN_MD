/************************************************************************
*
* MODULE: dbg_PrintLog.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to print the logs from flash
*
*************************************************************************/
#ifndef DBG_PRINTLOG_H
#define DBG_PRINTLOG_H

/////////////
// Prototypes
/////////////
void PrintLog(void);

#endif
