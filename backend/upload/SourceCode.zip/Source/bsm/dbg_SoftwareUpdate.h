/************************************************************************
*
* MODULE: dbg_SoftwareUpdate.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to update the software
*
*************************************************************************/
#ifndef DBG_SOFTWAREUPDATE_H
#define DBG_SOFTWAREUPDATE_H

/////////////
// Prototypes
/////////////
void SoftwareUpdate(char* Parameters);

#endif
