/************************************************************************
*
* MODULE: dbg_led.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to debug the LEDs.
*
*************************************************************************/
#ifndef DBG_LED_H
#define BDG_LED_H

/////////////
// Prototypes
/////////////
void SetLed(char* CommandLineParameters);

#endif

