/************************************************************************
*
* MODULE: dbg_speaker.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function to debug the speaker.
*
*************************************************************************/
#ifndef DBG_SPEAKER_H
#define BDG_SPEAKER_H

/////////////
// Prototypes
/////////////
void SetAudioSpeaker(char* CommandLineParameters);

#endif
