/************************************************************************
*
* MODULE: dbg_TestInternalRam.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the functions to test the internal RAM.
*
*************************************************************************/
#ifndef DBG_TESTINTERNALRAM_H
#define DBG_TESTINTERNALRAM_H

/////////////
// Prototypes
/////////////
BOOL TestInternalRam(void);

#endif
