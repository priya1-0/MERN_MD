/************************************************************************
*
* MODULE: dbg_SendTelemAMessage.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function test the telemetry to a device
*
*************************************************************************/
#ifndef DBG_SENDTELEMAMESSAGE_H
#define DBG_SENDTELEMAMESSAGE_H

/////////////
// Prototypes
/////////////
void SendTelemetryAMessage(char* CommandLine);

#endif


