/************************************************************************
*
* MODULE: bsm_DebugPort.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function declarations for the
*              serial port.
*
*************************************************************************/
#ifndef BSM_DEBUGPORT_H
#define BSM_DEBUGPORT_H

///////////////
// prototypes
///////////////

void bsm_CheckDebugPort(void);

#endif

