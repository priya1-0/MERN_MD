/************************************************************************
*
* MODULE: dbg_password.h
*
* $Revision$
*
* $Date$
*
* $RCSfile$
*
* DESCRIPTION: This file contains the function declarations for the
*              passwords.
*
*************************************************************************/
#ifndef DGB_PASSWORD_H
#define DGB_PASSWORD_H

///////////////
// prototypes
///////////////
BOOL CheckPassword(void);


#endif
