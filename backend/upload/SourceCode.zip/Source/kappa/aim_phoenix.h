/*
************************************************************************
 2490 In-home Remote Monitor
 Copyright (c) Medtronic, Inc. 2016

 MODULE: Phoenix Interrogation Module

 OWNER: Medtronic

 DESCRIPTION:

 GLOBAL MODULE DATA:

 STATIC MODULE DATA:

 ENDPURPOSE

************************************************************************
*/

#ifndef aim_phoenix_h
#define aim_phoenix_h

void aim_PhoenixPreInterrogate(void);
void aim_PhoenixInterrogate(void);

#endif