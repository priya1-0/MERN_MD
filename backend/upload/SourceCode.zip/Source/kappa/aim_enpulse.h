/*
************************************************************************
 2490 In-home Remote Monitor
 Copyright (c) Medtronic, Inc. 2001

 MODULE: Kappa 900 Interrogation Module

 OWNER: Medtronic

 DESCRIPTION:

 GLOBAL MODULE DATA:

 STATIC MODULE DATA:

 ENDPURPOSE

************************************************************************
*/

#ifndef aim_ENPULSE_h
#define aim_ENPULSE_h

#include "aim_kappa.h"
void aim_EnpulsePreInterrogate(void);
void aim_EnpulseInterrogate(void);

#endif