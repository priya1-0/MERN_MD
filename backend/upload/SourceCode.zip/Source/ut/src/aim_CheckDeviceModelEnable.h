#include <stdbool.h>

typedef char BYTE;
typedef unsigned short USHORT;
typedef unsigned long ULONG;
typedef unsigned int UNSIGNED;
typedef void VOID;

typedef unsigned char UINT8;
typedef unsigned int UINT16;
typedef unsigned long UINT32;
typedef char INT8;
typedef int INT16;
typedef long INT32;

bool aim_CheckPhone4(unsigned long deviceId);