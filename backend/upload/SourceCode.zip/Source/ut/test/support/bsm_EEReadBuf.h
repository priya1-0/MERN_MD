#include "com_eepromapp.h"


void bsm_EEReadBuf(unsigned char* buffer, unsigned int Length, unsigned int Addr);

