#include "../bsm/bsm_daa.h"

#define  FAST_PERIPH_CLK_DIV  (2)
#define  SLOW_PERIPH_CLK_DIV  (2)
