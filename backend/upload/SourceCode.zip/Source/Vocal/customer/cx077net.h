"# Plexus LANsEND Configuration file\n"
"hostname LANsEND\n"
